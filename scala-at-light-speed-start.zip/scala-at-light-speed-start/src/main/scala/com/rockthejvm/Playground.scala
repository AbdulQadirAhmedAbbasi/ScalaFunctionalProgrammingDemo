package com.rockthejvm

object Playground extends App {
  println("I love Functional Programming with Scala!")
}
